#!/usr/bin/env python3
"""
Simulación de tráfico generada por SUMO Helper
Archivo: simulation_map_-25337_-25347_-57501_-57511

Para ejecutar esta simulación:
1. Asegúrate de tener SUMO instalado: sudo apt-get install sumo sumo-tools sumo-gui sumo-doc
2. Ejecuta: python3 run_simulation.py
"""

import os
import sys
import subprocess
import tempfile
from pathlib import Path

def run_simulation():
    # Get the directory where this script is located
    script_dir = Path(__file__).parent.absolute()
    
    print(f"=== Simulación de Tráfico: simulation_map_-25337_-25347_-57501_-57511 ===")
    print(f"Directorio: {script_dir}")
    print()
    
    # Check if SUMO is installed
    try:
        result = subprocess.run(["sumo-gui", "--version"], check=True, capture_output=True, text=True)
        print(f"SUMO-GUI encontrado: {result.stdout.split()[1]}")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("ERROR: sumo-gui no está instalado o no está en el PATH")
        print("Instala SUMO con: sudo apt-get install sumo sumo-tools sumo-gui sumo-doc")
        return False
    
    # Generate network with netconvert
    print("\nGenerando red con netconvert...")
    netconvert_cmd = [
        "netconvert",
        "--node-files", "nodes.nod.xml",
        "--edge-files", "edges.edg.xml",
        "--output-file", "network.net.xml",
        "--no-turnarounds",
        "--tls.guess", "true"
    ]
    
    result = subprocess.run(netconvert_cmd, cwd=script_dir, capture_output=True, text=True)
    if result.returncode != 0:
        print("❌ Error generando la red:")
        print(result.stderr)
        return False
    
    print("✅ Red generada: network.net.xml")
    
    # Start simulation
    print("\nIniciando simulación en SUMO-GUI...")
    sumo_cmd = ["sumo-gui", "-c", "simulation.sumocfg", "--no-step-log", "true"]
    subprocess.run(sumo_cmd, cwd=script_dir)
    
    return True

if __name__ == "__main__":
    run_simulation()
